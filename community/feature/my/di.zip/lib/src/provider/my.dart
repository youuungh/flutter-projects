import 'package:core_util/util.dart';
import 'package:flutter/material.dart';
import 'package:my_data/data.dart';
import 'package:my_domain/domain.dart';
import 'package:my_presentation/presentation.dart';
import 'package:tool_community_network/network.dart';

class MyProvider extends StatelessWidget {
  const MyProvider({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Provider<IProfileRemoteDataSource>(
      create: (context) =>
          ProfileRemoteDataSource(ProfileApi(Modular.get<CommunityRestClient>())),
      child: Provider<MyDataSource>(
        create: (context) => MyDataSource(
          Provider.of<IProfileRemoteDataSource>(context, listen: false),
        ),
        child: Provider<IMyRepository>(
          create: (context) =>
              MyRepository(Provider.of<MyDataSource>(context, listen: false)),
          child: Provider<GetMyPageUseCase>(
            create: (context) => GetMyPageUseCase(
              Provider.of<IMyRepository>(context, listen: false),
            ),
            child: ChangeNotifierProvider<MyViewModel>(
              create: (context) => MyViewModel(
                Provider.of<GetMyPageUseCase>(context, listen: false),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}
